# Protect Self ProtectPy3
Fungsinya? 
Kelebihan : 
1. Protect Group Line Pastinya 
2. Command Bisa Dipakai oleh Orang Admin/Self 
3. Bot Tidak Saling Kick Ketika Ada Yang Terkick 
4. Jika Ingin lebih dari 1 bot bisa ditambahkan sendiri 

- Kelemahan: 
- BOT Tidak Aktif Ketika Bot Induk Tidak ada di Dalam Group 

Cara Instal di termux: 
- pkg install python3 
- pkg install pip3 
- pkg install git 
- git clone https://github.com/wongmu/protectpy3 
- pip3 install rsa 
- pip3 install thrift==0.11.0 
- pip3 install humanfriendly
- pip3 install requests 
- cd protectpy3
- python3 protectpy3.py


Cara Install Self ProtectPy3 di c9: 
- apt update 
- apt install git 
- apt install python3 
- apt install pip3==python3 
- pip3 install rsa 
- pip3 install thrift 
- pip3 install requests 
- pip3 install humanfriendly 
- git clone https://github.com/wongmu/protectpy3 
- cd protectpy3 
- python3 protectpy3.py 


Credit By Eva. 
- Add My ID LINE : https://line.me/ti/p/~mamanggd 


Thx To : 
- LINE-TCR TEAM 
- HELLO-WORLD 
- Nadya Sutjiadi
- iiipuuul
